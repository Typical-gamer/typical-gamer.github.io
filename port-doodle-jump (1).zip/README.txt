A Pen created at CodePen.io. You can find this one at http://codepen.io/anon/pen/waMbXe.

 

Forked from [Hooker Juggernaut](http://codepen.io/secretgspot/)'s Pen [port Doodle Jump](http://codepen.io/secretgspot/pen/wqlch/).